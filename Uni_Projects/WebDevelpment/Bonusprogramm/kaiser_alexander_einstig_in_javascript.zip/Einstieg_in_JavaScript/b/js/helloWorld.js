// Warten bis Dom vollständig geladen
document.addEventListener('DOMContentLoaded', function() {
    console.log('Hello World!');
});