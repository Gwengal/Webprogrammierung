// Warten bis DOM vollständig geladen
document.addEventListener('DOMContentLoaded', function () {
    alert('Hello World!');
})